package com.admin.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class User {

	private String id;
	private String emailId;
	@JsonIgnoreProperties
	private String password;
	private String fullName;
	
	public User() {
	}

	public User(String id, String emailId, String password, String fullName) {
		this.id = id;
		this.emailId = emailId;
		this.password = password;
		this.fullName = fullName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
}
