package com.admin.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.admin.model.Washer;

@FeignClient(name="Washer-Service")
public interface WasherProxy {

	    @GetMapping("washer/get")
	    public List<Washer> findAll();
}
