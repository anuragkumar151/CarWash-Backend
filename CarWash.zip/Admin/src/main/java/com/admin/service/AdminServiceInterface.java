package com.admin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.admin.model.BookingDetails;
import com.admin.model.Washer;

@Service
public interface AdminServiceInterface {

	List<BookingDetails> bookingDetails();
	public BookingDetails findOne(String orderId);
	public void deleteOrder(String orderId);
	List<Washer> washer();
	public void deleteWasher(int wid);
}
