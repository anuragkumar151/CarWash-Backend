package com.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.admin.feign.BookingProxy;
import com.admin.feign.WasherProxy;
import com.admin.model.BookingDetails;
import com.admin.model.Washer;

@Service
public class AdminService implements AdminServiceInterface {

	@Autowired
	private BookingProxy bookingProxy;

	@Autowired
	private WasherProxy washerProxy;

	public List<BookingDetails> bookingDetails() {
		return bookingProxy.findAll();
	}

	public BookingDetails findOne(String orderId) {
		return bookingProxy.findOne(orderId);
	}

	public void deleteOrder(String orderId) {
		bookingProxy.deleteOrder(orderId);
	}

	public List<Washer> washer() {
		return washerProxy.findAll();
	}

	public void deleteWasher(int wid) {
		washerProxy.deleteWasher(wid);
	}
}