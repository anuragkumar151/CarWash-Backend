package com.admin.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.admin.model.BookingDetails;
import com.admin.model.WashPack;
import com.admin.model.Washer;
import com.admin.service.AdminServiceInterface;
import com.admin.service.WashPackServiceInterface;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
@RequestMapping("/Admin")
public class AdminController {

	private static final Logger Logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private WashPackServiceInterface washPackServiceInterface;

	@Autowired
	private AdminServiceInterface adminServiceInterface;

	@PostMapping("/add")
	public ResponseEntity<WashPack> addWashPack(@RequestBody WashPack washPack) {
		Logger.info("Adding new wash pack");
		return ResponseEntity.ok(washPackServiceInterface.addWashPack(washPack));
	}

	@GetMapping("/get")
	public ResponseEntity<List<WashPack>> getAllWashPacks() {
		Logger.info("Fetching all wash packs");
		return ResponseEntity.ok(washPackServiceInterface.getAllWashPacks());
	}

	@GetMapping("/get/{name}")
	public ResponseEntity<WashPack> findWashPackByName(@PathVariable String name) {
		Logger.info("Fetching wash pack by name");
		return ResponseEntity.ok(washPackServiceInterface.findWashPackByName(name));
	}

	@DeleteMapping("/{id}")
	public void deleteWashPack(@PathVariable String id) {
		Logger.info("Deleting wash pack with ID");
		washPackServiceInterface.deleteWashPack(id);
	}

	@PutMapping("/{id}")
	public ResponseEntity<WashPack> updateWashPack(@PathVariable String id, @RequestBody WashPack washPack) {
		Logger.info("Updating wash pack with ID");
		return ResponseEntity.ok(washPackServiceInterface.updateWashPack(id, washPack));
	}

	@GetMapping("booking/all")
	@CircuitBreaker(name = "washerService", fallbackMethod = "handleFallback")
	public List<BookingDetails> getorder() {
		Logger.info("Fetching all booking details");
		return adminServiceInterface.bookingDetails();
	}

	@GetMapping("/booking/{orderId}")
	public BookingDetails getBookingDetails(@PathVariable String orderId) {
		Logger.info("Fetching booking details for order ID");
		return adminServiceInterface.findOne(orderId);
	}

	@DeleteMapping("/booking/{orderId}")
	public void deleteBooking(@PathVariable String orderId) {
		Logger.info("Deleting booking with ID");
		adminServiceInterface.deleteOrder(orderId);
	}

	@GetMapping("washer/get")
	public List<Washer> getAllWashers() {
		Logger.info("Fetching all washers");
		return adminServiceInterface.washer();
	}
}
