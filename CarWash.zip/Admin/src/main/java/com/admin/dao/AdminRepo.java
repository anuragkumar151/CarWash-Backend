package com.admin.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.admin.model.Admin;
import com.admin.model.WashPack;

public interface AdminRepo extends MongoRepository<WashPack, String> {
	 WashPack findByName(String name);
	
	
}
