package com.admin.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.admin.model.WashPack;

public interface WasherRepo extends MongoRepository<WashPack, String> {
	 WashPack findByName(String name); 
	
}
