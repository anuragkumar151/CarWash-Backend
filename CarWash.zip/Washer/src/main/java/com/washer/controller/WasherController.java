package com.washer.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.washer.model.Washer;
import com.washer.service.WasherServiceInterface;

@RestController
@RequestMapping("/washer")
public class WasherController {

	@Autowired
	private WasherServiceInterface washerServiceInterface;

	private static final Logger LOGGER = LoggerFactory.getLogger(WasherController.class);

	@GetMapping("/get")
	public List<Washer> findAll() {
		LOGGER.info("Fetching all washers");
		return washerServiceInterface.findAll();
	}

	@GetMapping("/random")
	public Washer getRandomWasher() {
		// Retrieve a random washer from the washer service
		return washerServiceInterface.getRandomWasher();
	}

	@GetMapping("/get/{wid}")
	public Washer getWasherById(@PathVariable int wid) {
		LOGGER.info("Fetching washer with ID: {}", wid);
		return washerServiceInterface.getUserById(wid);
	}

	@PostMapping("/add")
	public Washer addWasher(@RequestBody Washer washer) {
		LOGGER.info("Adding new washer: {}", washer);
		return washerServiceInterface.saveUser(washer);
	}

	@PutMapping("/update/{wid}")
	public Washer updateWasher(@PathVariable int wid, @RequestBody Washer washer) {
		LOGGER.info("Updating washer with ID: {}", wid);
		return washerServiceInterface.updateUser(wid, washer);
	}

	@DeleteMapping("/{wid}")
	public void deleteWasher(@PathVariable int wid) {
		LOGGER.info("Deleting washer with ID: {}", wid);
		washerServiceInterface.deleteUser(wid);
	}

}
