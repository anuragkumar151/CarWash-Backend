package com.washer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.washer.dao.WasherRepo;
import com.washer.model.Washer;

@Service
public class CustomUserDetailsService implements UserDetailsService{
	
	@Autowired
	private WasherRepo washerRepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		Washer washer = washerRepo.findByEmail(username);
		return washer;
	}

}
