package com.washer.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.washer.dao.WasherRepo;
import com.washer.model.Washer;

@Service
public class WasherService implements WasherServiceInterface {

	@Autowired
	private WasherRepo washerRepo;

	@Autowired
	private PasswordEncoder passwordEncoder;

	public List<Washer> findAll() {
		return washerRepo.findAll();
	}

	public Washer getRandomWasher() {
		List<Washer> allWashers = washerRepo.findAll();

		if (allWashers.isEmpty()) {
			throw new IllegalStateException("No washers found");
		}

		int randomIndex = new Random().nextInt(allWashers.size());
		return allWashers.get(randomIndex);
	}

	public Washer getUserById(int wid) {
		return washerRepo.findById(wid).orElse(null);
	}

	public Washer saveUser(Washer washer) {
		washer.setPassword(passwordEncoder.encode(washer.getPassword()));
		return washerRepo.save(washer);
	}

	public Washer updateUser(int wid, Washer washer) {
		Washer existingUser = washerRepo.findById(wid).orElse(null);

		if (existingUser != null) {
			// Update the fields of the existing user with the values from the updated user
			existingUser.setFullname(washer.getFullname());
			existingUser.setEmail(washer.getEmail());
			existingUser.setPassword(washer.getPassword());
			existingUser.setContactNo(washer.getContactNo());

			// Save the updated user to the database
			return washerRepo.save(existingUser);
		}
		return null; // User not found
	}

	public void deleteUser(int wid) {
		washerRepo.deleteById(wid);
	}
}
