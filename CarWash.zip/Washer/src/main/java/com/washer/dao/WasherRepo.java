package com.washer.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.washer.model.Washer;

public interface WasherRepo extends JpaRepository<Washer , Integer>{
	
	public Washer findByEmail(String email);
}
