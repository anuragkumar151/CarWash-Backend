package com.example.washer;

import com.washer.controller.WasherController;
import com.washer.model.Washer;
import com.washer.service.WasherServiceInterface;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class WasherControllerTest {

    @Mock
    private WasherServiceInterface washerServiceInterface;

    @InjectMocks
    private WasherController washerController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindAll() {
        // Arrange
        List<Washer> washers = new ArrayList<>();
        washers.add(new Washer(1, "Washer 1", "Hrishikesh@gmail.com", "qwerty","7485961235"));
        washers.add(new Washer(2, "Washer 2", "John@gmail.com", "qwerty","74512369854"));
        when(washerServiceInterface.findAll()).thenReturn(washers);

        // Act
        List<Washer> result = washerController.findAll();

        // Assert
        assertEquals(washers, result);
        verify(washerServiceInterface).findAll();
    }

    @Test
    void testGetWasherById() {
        // Arrange
        int wid = 1;
        Washer expectedWasher = new Washer(1, "Washer 1", "Hrishikesh@gmail.com", "qwerty","7485961235");
        when(washerServiceInterface.getUserById(wid)).thenReturn(expectedWasher);

        // Act
        Washer result = washerController.getWasherById(wid);

        // Assert
        assertEquals(expectedWasher, result);
        verify(washerServiceInterface).getUserById(wid);
    }

    @Test
    void testAddWasher() {
        // Arrange
        Washer washer = new Washer(1, "Washer 1", "Hrishikesh@gmail.com", "qwerty","7485961235");
        when(washerServiceInterface.saveUser(any(Washer.class))).thenReturn(washer);

        // Act
        Washer result = washerController.addWasher(washer);

        // Assert
        assertEquals(washer, result);
        verify(washerServiceInterface).saveUser(any(Washer.class));
    }


    @Test
    void testDeleteWasher() {
        // Arrange
        int wid = 1;

        // Act
        washerController.deleteWasher(wid);

        // Assert
        verify(washerServiceInterface).deleteUser(wid);
    }
}
