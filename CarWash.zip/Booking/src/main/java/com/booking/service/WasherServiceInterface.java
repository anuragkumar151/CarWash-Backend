package com.booking.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.booking.model.Washer;

@Service
public interface WasherServiceInterface {
	
	public List<Washer> All();

	public Washer RandomWasher();
}
