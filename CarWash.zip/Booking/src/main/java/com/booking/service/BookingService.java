package com.booking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.dao.BookingRepo;
import com.booking.exception.BookingNotFoundException;
import com.booking.model.BookingDetails;

@Service
public class BookingService implements BookingServiceInterface {

	@Autowired
	private BookingRepo bookingRepo;

	// Find all orders
	public List<BookingDetails> findAll() {

		List<BookingDetails> booking = bookingRepo.findAll();
		if (booking.isEmpty()) {
			throw new BookingNotFoundException("No Booking Found");
		}
		return booking;
	}

	// Find order by id
	public BookingDetails findOne(int orderId) {

		BookingDetails booking = bookingRepo.findById(orderId).get();
		if (booking == null) {
			throw new BookingNotFoundException("Booking not found for orderId: " + orderId);
		}
		return booking;
	}

	// To add an order
	public BookingDetails addOrder(BookingDetails booking) {
		 int orderId = booking.getOrderId();
		    if (bookingRepo.existsById(orderId)) {
		        throw new IllegalArgumentException("Booking with ID: " + orderId + " already exists");
		    }
		    return bookingRepo.save(booking);
		}

	// To delete
	public void deleteOrder(int orderId) {

		bookingRepo.deleteById(orderId);
	}

	// To Update
	public BookingDetails updateBookingDetails(int orderId, BookingDetails bookingDetails) {

		BookingDetails booking = bookingRepo.findById(orderId).get();
		if (booking == null) {
			throw new BookingNotFoundException("Booking not found for orderID: " + orderId);
		}
		booking.setWashPack(bookingDetails.getWashPack());
		booking.setCarName(bookingDetails.getCarName());
		booking.setUseremailId(bookingDetails.getUseremailId());
		booking.setPhoneNo(bookingDetails.getPhoneNo());
		booking.setAddress(bookingDetails.getAddress());
		booking.setDate(bookingDetails.getDate());
		booking.setTime(bookingDetails.getTime());
		BookingDetails savedBooking = bookingRepo.save(booking);
		return savedBooking;
	}

}
