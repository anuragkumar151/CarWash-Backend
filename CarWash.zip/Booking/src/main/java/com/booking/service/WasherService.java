package com.booking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.feign.WasherProxy;
import com.booking.model.Washer;

@Service
public class WasherService implements WasherServiceInterface{

	@Autowired
	private WasherProxy washerProxy;
	
	public List<Washer> All() {
		return washerProxy.findAll();
	}
	
	public Washer RandomWasher() {
		return washerProxy.getRandomWasher();
	}
}
