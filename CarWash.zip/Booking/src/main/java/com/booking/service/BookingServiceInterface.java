package com.booking.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.booking.model.BookingDetails;

@Service
public interface BookingServiceInterface {

	public List<BookingDetails> findAll();
	public BookingDetails findOne(int orderId);
	public List<BookingDetails> findByEmail(String email);
	public BookingDetails addOrder(BookingDetails booking);
	public void sendBookingConfirmationEmail(BookingDetails booking);
	public BookingDetails updateBookingDetails(int orderId, BookingDetails bookingDetails);
	public void deleteOrder(int orderId);
	
}
