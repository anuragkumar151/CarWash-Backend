package com.booking.controller;

import java.util.*;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.booking.exception.BookingNotFoundException;
import com.booking.model.BookingDetails;
import com.booking.model.TransactionDetails;
import com.booking.model.Washer;
import com.booking.service.BookingServiceInterface;
import com.booking.service.TransactionService;
import com.booking.service.WasherServiceInterface;

@RestController
@RequestMapping("/booking")
@CrossOrigin
public class BookingController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BookingController.class);

	@Autowired
	private BookingServiceInterface bookingServiceInterface;

	@Autowired
	private WasherServiceInterface washerServiceInterface;
	
	@Autowired
	private TransactionService transactionservice;

	private final Map<Integer, Integer> washerAssignments = new HashMap<>();

	  @GetMapping("/createTransaction/{amount}")
	    public TransactionDetails createTransaction(@PathVariable Double amount) {
       return transactionservice.createTransaction(amount);
	    }
	  
	@GetMapping("/all")
	public List<BookingDetails> findAll() {
		LOGGER.info("Fetching all bookings");
		return bookingServiceInterface.findAll();
	}

	@GetMapping("/{orderId}")
	public BookingDetails findOne(@PathVariable int orderId) throws BookingNotFoundException {
		LOGGER.info("Fetching booking with ID");
		return bookingServiceInterface.findOne(orderId);
	}

	@GetMapping("user/{email}")
	public List<BookingDetails> getUserDetailsByEmail(@PathVariable String email) {
	    LOGGER.info("Fetching user details by email: {}", email);
	   return bookingServiceInterface.findByEmail(email);
	}
		
	@PostMapping("/add")
	public ResponseEntity<BookingDetails> addBooking(@RequestBody BookingDetails booking)
			throws BookingNotFoundException {
		LOGGER.info("Adding new booking");
		BookingDetails addedBooking = bookingServiceInterface.addOrder(booking);
	    bookingServiceInterface.sendBookingConfirmationEmail(addedBooking);
	    return ResponseEntity.ok(addedBooking);
	}
	

//	@PostMapping("/washer/random")
//	public ResponseEntity<String> createBooking(@RequestBody BookingDetails booking) {
//		// Create booking logic here
//
//		// Fetch a random washer from the washer microservice
//		Washer washer = washerServiceInterface.RandomWasher();
//
//		// Check if the washer is already assigned to two users
//		Integer assignedUsersCount = washerAssignments.getOrDefault(washer.getWid(), 0);
//		if (assignedUsersCount >= 2) {
//			return ResponseEntity.badRequest().body("Washer is fully assigned");
//		}
//
//		// Assign the washer to the booking
//		// ...
//
//		// Update the washer assignments count
//		washerAssignments.put(washer.getWid(), assignedUsersCount + 1);
//		bookingServiceInterface.addOrder(booking);
//		// Return the response
//		return ResponseEntity.ok("Booking created successfully with washer: " + washer.getWid());
//	}

	@PutMapping("/{orderId}")
	public ResponseEntity<BookingDetails> updateBooking(@PathVariable int orderId,
			@RequestBody BookingDetails bookingDetails) {
		LOGGER.info("Updating booking with ID");
		return ResponseEntity.ok(bookingServiceInterface.updateBookingDetails(orderId, bookingDetails));
	}
	
	@PutMapping("/edit/{email}")
	public ResponseEntity<BookingDetails> updateBookingDetailsByEmail(@PathVariable String email, @RequestBody BookingDetails bookingDetails) {
		LOGGER.info("Updating booking with email");
		return ResponseEntity.ok(bookingServiceInterface.updateBookingDetailsByEmail(email, bookingDetails));
	}

	@DeleteMapping("/{orderId}")
	public void deleteOrder(@PathVariable int orderId) {
		LOGGER.info("Deleting booking with ID");
		bookingServiceInterface.deleteOrder(orderId);
	}

	@GetMapping("/washer/get")
	public List<Washer> getAllWashers() {
		LOGGER.info("Fetching all washers");
		return washerServiceInterface.All();
	}

}
