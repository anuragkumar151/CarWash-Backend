package com.booking.controller;

import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.booking.exception.BookingNotFoundException;
import com.booking.model.BookingDetails;
import com.booking.model.BookingResponse;
import com.booking.model.Washer;
import com.booking.service.BookingServiceInterface;
import com.booking.service.WasherServiceInterface;

@RestController
@RequestMapping("/booking")
public class BookingController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BookingController.class);

	@Autowired
	private BookingServiceInterface bookingServiceInterface;

	@Autowired
	private WasherServiceInterface washerServiceInterface;

	private final Map<Integer, Integer> washerAssignments = new HashMap<>();

	@GetMapping("/all")
	public List<BookingDetails> findAll() {
		LOGGER.info("Fetching all bookings");
		return bookingServiceInterface.findAll();
	}

	@GetMapping("/{orderId}")
	public BookingDetails findOne(@PathVariable int orderId) throws BookingNotFoundException {
		LOGGER.info("Fetching booking with ID");
		return bookingServiceInterface.findOne(orderId);
	}

//	@PostMapping("/add")
//	public ResponseEntity<BookingDetails> addBooking(@RequestBody BookingDetails booking)
//			throws BookingNotFoundException {
//		LOGGER.info("Adding new booking");
//		return ResponseEntity.ok(bookingServiceInterface.addOrder(booking));
//	}

	@PostMapping("/washer/random")
	public ResponseEntity<String> createBooking(@RequestBody BookingDetails booking) {
		// Create booking logic here

		// Fetch a random washer from the washer microservice
		Washer washer = washerServiceInterface.RandomWasher();

		// Check if the washer is already assigned to two users
		Integer assignedUsersCount = washerAssignments.getOrDefault(washer.getWid(), 0);
		if (assignedUsersCount >= 2) {
			return ResponseEntity.badRequest().body("Washer is fully assigned");
		}

		// Assign the washer to the booking
		// ...

		// Update the washer assignments count
		washerAssignments.put(washer.getWid(), assignedUsersCount + 1);
		bookingServiceInterface.addOrder(booking);
		// Return the response
		return ResponseEntity.ok("Booking created successfully with washer: " + washer.getWid());
	}

	@PutMapping("/{orderId}")
	public ResponseEntity<BookingDetails> updateBooking(@PathVariable int orderId,
			@RequestBody BookingDetails bookingDetails) {
		LOGGER.info("Updating booking with ID");
		return ResponseEntity.ok(bookingServiceInterface.updateBookingDetails(orderId, bookingDetails));
	}

	@DeleteMapping("/{orderId}")
	public void deleteOrder(@PathVariable int orderId) {
		LOGGER.info("Deleting booking with ID");
		bookingServiceInterface.deleteOrder(orderId);
	}

	@GetMapping("/washer/get")
	public List<Washer> getAllWashers() {
		LOGGER.info("Fetching all washers");
		return washerServiceInterface.All();
	}

}
