package com.booking.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import jakarta.persistence.Entity;
import jakarta.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BookingDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int orderId;
	private String carName;
	private String useremailId;
	private String phoneNo;
	private String washPack;
	@JsonFormat(pattern = "dd-MM-yyyy", shape = Shape.STRING)
	private String date;
	@JsonFormat(pattern = "HH:mm")
	private String time;
	private String address;

}