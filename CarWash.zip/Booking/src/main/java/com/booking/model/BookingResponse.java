package com.booking.model;

public class BookingResponse {
    private BookingDetails booking;
    private Washer washer;

    public BookingResponse(BookingDetails booking, Washer washer) {
        this.booking = booking;
        this.washer = washer;
    }

    public BookingDetails getBooking() {
        return booking;
    }

    public void setBooking(BookingDetails booking) {
        this.booking = booking;
    }

    public Washer getWasher() {
        return washer;
    }

    public void setWasher(Washer washer) {
        this.washer = washer;
    }
}
