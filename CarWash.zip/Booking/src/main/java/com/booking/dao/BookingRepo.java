package com.booking.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.booking.model.BookingDetails;

public interface BookingRepo extends JpaRepository<BookingDetails, Integer>{

	 List<BookingDetails> findByEmail(String email);
}
