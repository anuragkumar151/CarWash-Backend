package com.example.user;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.user.controller.UserController;
import com.user.model.Ratings;
import com.user.model.User;
import com.user.service.RatingServiceInterface;
import com.user.service.UserServiceInterface;



public class UserApplicationTests {

	@Mock
	private UserServiceInterface userServiceInterface;

	@Mock
	private RatingServiceInterface ratingServiceInterface;

	@InjectMocks
	private UserController userController;


	@BeforeEach
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetUserById() {
		User user = new User();
		user.setUserId(1);
		user.setFullname("John");
		when(userServiceInterface.getUserById(1)).thenReturn(user);

		User result = userController.getUserById(1);

		assertEquals(user, result);
		verify(userServiceInterface).getUserById(1);
	}

	@Test
	public void testCreateUser() {
		User user = new User();
		user.setFullname("John");
		when(userServiceInterface.createUser(user)).thenReturn(user);

		User result = userController.createUser(user);

		assertEquals(user, result);
		verify(userServiceInterface).createUser(user);
	}

	@Test
	public void testUpdateUser() {
		User user = new User();
		user.setUserId(1);
		user.setFullname("John");
		when(userServiceInterface.updateUser(1, user)).thenReturn(user);

		User result = userController.updateUser(1, user);

		assertEquals(user, result);
		verify(userServiceInterface).updateUser(1, user);
	}

	@Test
	public void testDeleteUser() {
		int id = 1;
		doNothing().when(userServiceInterface).deleteUser(id);

		userController.deleteUser(id);

		verify(userServiceInterface).deleteUser(id);
	}

	@Test
	public void testGetAllRatings() {
		Ratings rating1 = new Ratings();
		rating1.setId("1");
		Ratings rating2 = new Ratings();
		rating2.setId("2");
		List<Ratings> ratingsList = Arrays.asList(rating1, rating2);
		when(ratingServiceInterface.getAllRatings()).thenReturn(ratingsList);

		List<Ratings> result = userController.getAllRatings();

		assertEquals(ratingsList, result);
		verify(ratingServiceInterface).getAllRatings();
	}

	@Test
	public void testGetRatingById() {
		Ratings rating = new Ratings();
		rating.setId("1");
		when(ratingServiceInterface.getRatingById("1")).thenReturn(rating);

		Ratings result = userController.getRatingById("1");

		assertEquals(rating, result);
		verify(ratingServiceInterface).getRatingById("1");
	}

	@Test
	public void testAddRating() {
		Ratings rating = new Ratings();
		when(ratingServiceInterface.addRating(rating)).thenReturn(rating);

		Ratings result = userController.addRating(rating);

		assertEquals(rating, result);
		verify(ratingServiceInterface).addRating(rating);
	}

	@Test
	public void testUpdateRating() {
		Ratings rating = new Ratings();
		rating.setId("1");
		Ratings updatedRating = new Ratings();
		updatedRating.setId("1");
		when(ratingServiceInterface.updateRating("1", updatedRating)).thenReturn(updatedRating);

		Ratings result = userController.updateRating("1", updatedRating);

		assertEquals(updatedRating, result);
		verify(ratingServiceInterface).updateRating("1", updatedRating);
	}

	@Test
	public void testDeleteRating() {
		String id = "1";
		doNothing().when(ratingServiceInterface).deleteRating(id);

		userController.deleteRating(id);

		verify(ratingServiceInterface).deleteRating(id);
	}
}
