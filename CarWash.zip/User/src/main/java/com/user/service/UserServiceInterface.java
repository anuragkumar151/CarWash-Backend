package com.user.service;

import com.user.model.User;

public interface UserServiceInterface {
	
	public User createUser(User user);
	public User getUserById(int id);
	public User updateUser(int id, User user);
	public void deleteUser(int id);
}
