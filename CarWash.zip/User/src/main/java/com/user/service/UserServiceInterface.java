package com.user.service;

import org.springframework.http.ResponseEntity;

import com.user.model.User;

public interface UserServiceInterface {
	
	public User createUser(User user);
	public User getUserById(int id);
	public User getUserByemail(String email);
	public User updateUser(int id, User user);
	public ResponseEntity<String> updateUserDetailsByEmail(String email,User updatedUser) ;
	public void deleteUser(int id);
}
