package com.user.service;

import java.util.List;

import com.user.model.Ratings;

public interface RatingServiceInterface {

	public List<Ratings> getAllRatings() ;
	public Ratings getRatingById(String id) ;
	public Ratings addRating(Ratings rating) ;
	public Ratings updateRating(String id, Ratings updatedRating);
	public void deleteRating(String id);
}
