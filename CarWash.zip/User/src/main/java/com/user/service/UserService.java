package com.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.user.dao.UserRepo;
import com.user.model.User;


@Service
public class UserService implements UserServiceInterface{
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	
	public User createUser(User user) {
		user.setPassword(passwordEncoder.encode(user.getPassword()));
	    return userRepo.save(user);
	}

	public User getUserById(int userId ) {
	    return userRepo.findByUserId(userId);
	}

	public User updateUser(int id, User user) {
	    if (!userRepo.existsById(id)) {
	        return null;
	    }
	    user.setUserId(id);
	    return userRepo.save(user);
	}

	public void deleteUser(int id) {
	    if (userRepo.existsById(id)) {
	        userRepo.deleteById(id);
	    }
	}
}
