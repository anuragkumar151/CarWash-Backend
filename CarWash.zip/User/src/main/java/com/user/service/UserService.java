package com.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.user.dao.UserRepo;
import com.user.model.User;

@Service
public class UserService implements UserServiceInterface {

	@Autowired
	private UserRepo userRepo;

	@Autowired
	private PasswordEncoder passwordEncoder;

	public User createUser(User user) {
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		return userRepo.save(user);
	}

	public User getUserById(int userId) {
		return userRepo.findByUserId(userId);
	}

	public User getUserByemail(String email) {
		return userRepo.findByEmail(email);
	}

	public User updateUser(int id, User updatedUser) {
		if (!userRepo.existsById(id)) {
			throw new IllegalArgumentException("User not found with ID: " + id);
		}

		updatedUser.setUserId(updatedUser.getUserId());
		updatedUser.setFullname(updatedUser.getFullname());
		updatedUser.setContactNo(updatedUser.getContactNo());
		updatedUser.setEmail(updatedUser.getEmail());
		updatedUser.setPassword(updatedUser.getPassword());

		return userRepo.save(updatedUser);
	}

	public ResponseEntity<String> updateUserDetailsByEmail(String email,User updatedUser) {

		User existingUser = userRepo.findByEmail(email);

		if (existingUser == null) {
			return new ResponseEntity<>("User with email " + email + " not found.", HttpStatus.NOT_FOUND);
		}

		// Update the necessary fields
		existingUser.setFullname(updatedUser.getFullname());
		existingUser.setContactNo(updatedUser.getContactNo());
		existingUser.setPassword(updatedUser.getPassword());

		// Save the updated user
		userRepo.save(existingUser);

		return new ResponseEntity<>("User details updated successfully.", HttpStatus.OK);
	}

	public void deleteUser(int id) {
		if (userRepo.existsById(id)) {
			userRepo.deleteById(id);
		}
	}
}
