package com.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.user.dao.UserRepo;
import com.user.model.User;


@Service
public class UserService implements UserServiceInterface{
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	
	public User createUser(User user) {
		user.setPassword(passwordEncoder.encode(user.getPassword()));
	    return userRepo.save(user);
	}

	public User getUserById(int userId ) {
	    return userRepo.findByUserId(userId);
	}
	public User updateUser(int id, User updatedUser) {
	    if (!userRepo.existsById(id)) {
	        throw new IllegalArgumentException("User not found with ID: " + id);
	    }

	    updatedUser.setUserId(updatedUser.getUserId());
	    updatedUser.setFullname(updatedUser.getFullname());
	    updatedUser.setContactNo(updatedUser.getContactNo());
	    updatedUser.setEmail(updatedUser.getEmail());
	    updatedUser.setPassword(updatedUser.getPassword());

	    return userRepo.save(updatedUser);
	}


	public void deleteUser(int id) {
	    if (userRepo.existsById(id)) {
	        userRepo.deleteById(id);
	    }
	}
}
