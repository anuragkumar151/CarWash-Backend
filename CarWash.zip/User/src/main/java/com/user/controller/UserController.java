package com.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.user.model.Ratings;
import com.user.model.User;
import com.user.service.RatingServiceInterface;
import com.user.service.UserServiceInterface;

@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	private UserServiceInterface userServiceInterface;

	@Autowired
	private RatingServiceInterface ratingServiceInterface;

	@GetMapping("/{id}")
	public User getUserById(@PathVariable int id) {
		return userServiceInterface.getUserById(id);
	}

	@PostMapping("/add")
	public User createUser(@RequestBody User user) {
		return userServiceInterface.createUser(user);
	}

	@PutMapping("/{id}")
	public User updateUser(@PathVariable int id, @RequestBody User user) {
		return userServiceInterface.updateUser(id, user);
	}

	@DeleteMapping("/{id}")
	public void deleteUser(@PathVariable int id) {
		userServiceInterface.deleteUser(id);
	}

	@GetMapping("/ratings")
	public List<Ratings> getAllRatings() {
		return ratingServiceInterface.getAllRatings();
	}

	@GetMapping("/ratings/{id}")
	public Ratings getRatingById(@PathVariable String id) {
		return ratingServiceInterface.getRatingById(id);
	}

	@PostMapping("/ratings/add")
	public Ratings addRating(@RequestBody Ratings rating) {
		return ratingServiceInterface.addRating(rating);
	}

	@PutMapping("/ratings/{id}")
	public Ratings updateRating(@PathVariable String id, @RequestBody Ratings updatedRating) {
		return ratingServiceInterface.updateRating(id, updatedRating);
	}

	@DeleteMapping("/ratings/{id}")
	public void deleteRating(@PathVariable String id) {
		ratingServiceInterface.deleteRating(id);
	}
}
