package com.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.user.dao.UserRepo;
import com.user.model.User;

@RestController
@CrossOrigin(origins="http://localhost:3000")
public class LoginController {

	@Autowired
	private UserRepo userRepo;
	
	@Autowired
    private PasswordEncoder passwordEncoder;
	
	 @PostMapping("/register")
	    public ResponseEntity<String> registerUser(@RequestBody User user) {
	        User savedUser = null;
	        ResponseEntity response = null;
	        try {
	            String hashPwd = passwordEncoder.encode(user.getPassword());
	            user.setPassword(hashPwd);
	            savedUser = userRepo.save(user);
	            if (savedUser.getUserId() > 0) {
	                response = ResponseEntity
	                        .status(HttpStatus.CREATED)
	                        .body("Given user details are successfully registered");
	            }
	        } catch (Exception ex) {
	            response = ResponseEntity
	                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
	                    .body("An exception occured due to " + ex.getMessage());
	        }
	        return response;
	    }
}
