package com.user.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.user.model.User;


public interface UserRepo extends JpaRepository<User, Integer> {

	public User findByEmail(String email);
	public User findByUserId(int userId);
}
