package com.user.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.user.model.User;

import jakarta.transaction.Transactional;

public interface UserRepo extends JpaRepository<User, Integer> {

//	@Transactional
//	    @Modifying
//	    @Query("UPDATE User u SET u.firstname = :firstname, u.lastname = :lastname, u.email = :email, u.password = :password WHERE u.id = :id")
//	    void updateUser(
//	            @Param("id") Integer id,
//	            @Param("firstname") String firstname,
//	            @Param("lastname") String lastname,
//	            @Param("email") String email,
//	            @Param("password") String password);

	public User findByEmail(String email);

	public User findByUserId(int userId);

}
