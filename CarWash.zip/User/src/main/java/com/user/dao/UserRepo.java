package com.user.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.user.model.User;

import jakarta.transaction.Transactional;

public interface UserRepo extends JpaRepository<User, Integer> {

	public User findByEmail(String email);

}
