package com.user.service;

import org.springframework.stereotype.Service;

import com.user.model.User;

@Service
public interface UserServiceInterface {
	
	public User createUser(User user);
	public User getUserById(String id);
	public User updateUser(String id, User user);
	public void deleteUser(String id);
}
