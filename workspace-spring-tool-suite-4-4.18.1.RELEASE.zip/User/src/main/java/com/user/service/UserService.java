package com.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.dao.UserRepo;
import com.user.model.User;

@Service
public class UserService implements UserServiceInterface{
	
	@Autowired
	private UserRepo userRepo;

	public User createUser(User user) {
		return userRepo.save(user);
	}

	public User getUserById(String id) {
		return userRepo.findById(id).orElse(null);
	}

	public User updateUser(String id, User user) {
		if (!userRepo.existsById(id)) {
			return null;
		}
		user.setId(id);
		return userRepo.save(user);
	}

	public void deleteUser(String id) {
	    if (userRepo.existsById(id)) {
	        userRepo.deleteById(id);
	    }
	}}
