package com.user.model;

public class BookingDetails {

	String orderId;
	String useremailId;
	long phoneNo;
	String washPack;
	String washerName;
	String pinCode;
	String Address;
	
	public BookingDetails() {
	}
	
	public BookingDetails(String orderId, String useremailId, long phoneNo, String washPack, String pinCode,String address, String washerName) {
		this.orderId = orderId;
		this.useremailId = useremailId;
		this.phoneNo = phoneNo;
		this.washPack = washPack;
		this.washerName = washerName;
		this.pinCode = pinCode;
		this.Address = address;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getUseremailId() {
		return useremailId;
	}

	public void setUseremailId(String useremailId) {
		this.useremailId = useremailId;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getWashPack() {
		return washPack;
	}

	public void setWashPack(String washPack) {
		this.washPack = washPack;
	}
	
	public String getWasherName() {
		return washerName;
	}
	
	public void setWasherName(String washerName) {
		this.washerName = washerName;
	}
	
	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		this.Address = address;
	}

}
