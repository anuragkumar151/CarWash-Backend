package com.admin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.admin.model.BookingDetails;

@Service
public interface AdminServiceInterface {
	public List<BookingDetails> getorder();
}
