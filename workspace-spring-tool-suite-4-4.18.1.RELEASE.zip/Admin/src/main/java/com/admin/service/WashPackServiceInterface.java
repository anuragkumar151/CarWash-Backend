package com.admin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.admin.model.WashPack;

@Service
public interface WashPackServiceInterface {
	 public WashPack addWashPack(WashPack washPack);
	 public List<WashPack> getAllWashPacks();
//	 public WashPack getWashPackById(String id);
	 public WashPack findWashPackByName(String name) ;
	 public void deleteWashPack(String id);
	 public WashPack updateWashPack(String id, WashPack washPack) ;
}
