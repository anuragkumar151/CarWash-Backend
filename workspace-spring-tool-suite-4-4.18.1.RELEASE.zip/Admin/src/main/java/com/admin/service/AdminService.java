package com.admin.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.admin.model.BookingDetails;

@Service
public class AdminService implements AdminServiceInterface{
		
	   @Autowired
	   private RestTemplate restTemplate;
	   
	   String url = "http://localhost:8083/booking/all";
	   
	   public List<BookingDetails> getorder() {
	       BookingDetails[] allorders = restTemplate.getForObject(url,BookingDetails[].class);
	       return Arrays.asList(allorders);
	   }


}