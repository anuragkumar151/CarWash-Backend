package com.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin.dao.WasherRepo;
import com.admin.model.WashPack;

@Service
public class WashPackService implements WashPackServiceInterface{
	
	    @Autowired
	    private WasherRepo washerRepo;

	    public WashPack addWashPack(WashPack washPack) {
	        return washerRepo.save(washPack);
	    }

	    public List<WashPack> getAllWashPacks() {
	        return washerRepo.findAll();
	    }

//	    public WashPack getWashPackById(String id) {
//	        WashPack washPack = washerRepo.findById(id).get();
//	        return washPack;
//	    }

	    public WashPack findWashPackByName(String name) {
	        return washerRepo.findByName(name);
	    }

	    public void deleteWashPack(String id) {
	    	washerRepo.deleteById(id);
	    }

	    public WashPack updateWashPack(String id, WashPack washPack) {
	        WashPack existingWashPack = washerRepo.findById(id).orElseThrow(() ->
	                new RuntimeException("Washpack with ID -> " + id + " not found, updating failed"));

	        existingWashPack.setName(washPack.getName());
	        existingWashPack.setCost(washPack.getCost());
	        existingWashPack.setDescription(washPack.getDescription());

	        return washerRepo.save(existingWashPack);
	    }

	}


