package com.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.admin.model.BookingDetails;
import com.admin.model.WashPack;
import com.admin.service.AdminServiceInterface;
import com.admin.service.WashPackServiceInterface;

@RestController
@RequestMapping("/washpacks")
public class AdminController {

    @Autowired
    private WashPackServiceInterface WP;
    
    private AdminServiceInterface AS;

    @PostMapping("/add")
    public ResponseEntity<WashPack> addWashPack(@RequestBody WashPack washPack) {
      return ResponseEntity.ok(WP.addWashPack(washPack));
    }

    @GetMapping("/get")
    public ResponseEntity<List<WashPack>> getAllWashPacks() {
        return ResponseEntity.ok(WP.getAllWashPacks());
    }

//    @GetMapping("/get/{id}")
//    public ResponseEntity<WashPack> getWashPackById(@PathVariable String id) {
//    	return ResponseEntity.ok(WP.getWashPackById(id));
//    }

    @GetMapping("/get/{name}")
    public ResponseEntity<WashPack> findWashPackByName(@PathVariable String name) {
        return ResponseEntity.ok(WP.findWashPackByName(name));
    }

    @DeleteMapping("/{id}")
    public void deleteWashPack(@PathVariable String id) {
    	WP.deleteWashPack(id);
     }

    @PutMapping("/{id}")
    public ResponseEntity<WashPack> updateWashPack(@PathVariable String id, @RequestBody WashPack washPack) {
        return ResponseEntity.ok(WP.updateWashPack(id, washPack));
    }
    
    @GetMapping("/all")
    public List<BookingDetails> getorder(){
		return AS.getorder();
    	
    }
}
