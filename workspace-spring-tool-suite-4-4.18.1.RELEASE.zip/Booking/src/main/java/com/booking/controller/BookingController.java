package com.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.booking.exception.BookingNotFoundException;
import com.booking.model.BookingDetails;
import com.booking.service.BookingServiceInterface;

@RestController
@RequestMapping("/booking")
public class BookingController {

	@Autowired
	private BookingServiceInterface bookingServiceInterface;

	@GetMapping("/all")
	public List<BookingDetails> findAll() {
		return bookingServiceInterface.findAll();
	}

	@GetMapping("/{orderId}")
	public BookingDetails findOne(@PathVariable String orderId) throws BookingNotFoundException {
		return bookingServiceInterface.findOne(orderId);
	}

	@PostMapping("/add")
	public ResponseEntity<BookingDetails> addBooking(@RequestBody BookingDetails booking)
			throws BookingNotFoundException {
		return ResponseEntity.ok(bookingServiceInterface.addOrder(booking));
	}

	@PutMapping("/{orderId}")
	public ResponseEntity<BookingDetails> updateBooking(@PathVariable String orderId,
			@RequestBody BookingDetails bookingDetails) {
		return ResponseEntity.ok(bookingServiceInterface.updateBookingDetails(orderId, bookingDetails));
	}

//	@GetMapping("/pending")
//	public ResponseEntity<List<BookingDetails>> getPendingOrders() {
//		return ResponseEntity.ok(bookingServiceInterface.getPendingOrders());
//	}
//
//	@PutMapping("/assignWasher")
//	public ResponseEntity<BookingDetails> assignWasher(@RequestBody BookingDetails bd) {
//		return ResponseEntity.ok(bookingServiceInterface.assignWasher(bd));
//	}
}
