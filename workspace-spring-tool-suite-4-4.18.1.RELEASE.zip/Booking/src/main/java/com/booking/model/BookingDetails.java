package com.booking.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class BookingDetails {

	@Id
	String orderId;
	String carName;
	String useremailId;
	long phoneNo;
	String washPack;
	String address;

	public BookingDetails() {
	}

	public BookingDetails(String orderId, String carName, String useremailId, long phoneNo, String washPack,
			String address) {
		this.orderId = orderId;
		this.carName = carName;
		this.useremailId = useremailId;
		this.phoneNo = phoneNo;
		this.washPack = washPack;
		this.address = address;

	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getUseremailId() {
		return useremailId;
	}

	public void setUseremailId(String useremailId) {
		this.useremailId = useremailId;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getWashPack() {
		return washPack;
	}

	public void setWashPack(String washPack) {
		this.washPack = washPack;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "BookingDetails [orderId=" + orderId + ", carName=" + carName + ",useremailId=" + useremailId
				+ ", phoneNo=" + phoneNo + ", washPack=" + washPack + ", address=" + address + "]";
	}

}
