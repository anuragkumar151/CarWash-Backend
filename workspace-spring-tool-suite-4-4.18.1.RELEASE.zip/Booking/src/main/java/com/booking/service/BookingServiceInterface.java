package com.booking.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.booking.model.BookingDetails;

@Service
public interface BookingServiceInterface {

	public List<BookingDetails> findAll();
	public BookingDetails findOne(String orderId);
	public BookingDetails addOrder(BookingDetails booking);
	public void deleteOrder(String orderId);
	public BookingDetails updateBookingDetails(String orderId, BookingDetails bookingDetails);
//	public List<BookingDetails> getPendingOrders();
//	public BookingDetails assignWasher(BookingDetails bd);
}
