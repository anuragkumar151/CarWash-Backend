package com.booking.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.booking.model.BookingDetails;

public interface BookingRepo extends MongoRepository<BookingDetails, String>{

	
}
