package com.example.user;

import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.user.controller.UserController;
import com.user.model.Ratings;
import com.user.model.User;
import com.user.service.RatingServiceInterface;
import com.user.service.UserServiceInterface;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class UserControllerTest {

    @Mock
    private UserServiceInterface userServiceInterface;

    @Mock
    private RatingServiceInterface ratingServiceInterface;

    @InjectMocks
    private UserController userController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllUsers() {
        List<User> users = new ArrayList<>();
        // Add users to the list

        when(userServiceInterface.getAllUsers()).thenReturn(users);

        List<User> result = userController.getAllUsers();

        assertEquals(users, result);
    }

    @Test
    public void testGetUserById() {
        int id = 1;
        User user = new User();
        // Set properties of user

        when(userServiceInterface.getUserById(id)).thenReturn(Optional.of(user));

        Optional<User> result = userController.getUserById(id);

        assertTrue(result.isPresent());
        assertEquals(user, result.get());
    }

    @Test
    public void testGetUserByEmail() {
        String email = "test@example.com";
        User user = new User();
        // Set properties of user

        when(userServiceInterface.getUserByemail(email)).thenReturn(user);

        User result = userController.getUserByEmail(email);

        assertEquals(user, result);
    }

    @Test
    public void testCreateUser() {
        User user = new User();
        // Set properties of user

        when(userServiceInterface.createUser(user)).thenReturn(user);

        User result = userController.createUser(user);

        assertEquals(user, result);
    }

    @Test
    public void testUpdateUser() {
        int id = 1;
        User user = new User();
        // Set properties of user

        when(userServiceInterface.updateUser(id, user)).thenReturn(user);

        User result = userController.updateUser(id, user);

        assertEquals(user, result);
    }

    @Test
    public void testUpdateUserByEmail() {
        String email = "test@example.com";
        User user = new User();
        // Set properties of user

        ResponseEntity<String> response = ResponseEntity.ok("Success");

        when(userServiceInterface.updateUserDetailsByEmail(email, user)).thenReturn(response);

        ResponseEntity<String> result = userController.updateUserByEmail(email, user);

        assertEquals(response, result);
    }

    @Test
    public void testDeleteUser() {
        int id = 1;

        userController.deleteUser(id);

        verify(userServiceInterface).deleteUser(id);
    }

    @Test
    public void testGetAllRatings() {
        List<Ratings> ratings = new ArrayList<>();
        // Add ratings to the list

        when(ratingServiceInterface.getAllRatings()).thenReturn(ratings);

        List<Ratings> result = userController.getAllRatings();

        assertEquals(ratings, result);
    }

    @Test
    public void testGetRatingById() {
        int id = 1;
        Ratings rating = new Ratings();
        // Set properties of rating

        when(ratingServiceInterface.getRatingById(id)).thenReturn(rating);

        Ratings result = userController.getRatingById(id);

        assertEquals(rating, result);
    }

    @Test
    public void testAddRating() {
        Ratings rating = new Ratings();
        // Set properties of rating

        when(ratingServiceInterface.addRating(rating)).thenReturn(rating);

        Ratings result = userController.addRating(rating);

        assertEquals(rating, result);
    }

    @Test
    public void testUpdateRating() {
        int id = 1;
        Ratings updatedRating = new Ratings();
        // Set properties of updatedRating

        when(ratingServiceInterface.updateRating(id, updatedRating)).thenReturn(updatedRating);

        Ratings result = userController.updateRating(id, updatedRating);

        assertEquals(updatedRating, result);
    }

    @Test
    public void testDeleteRating() {
        int id = 1;

        userController.deleteRating(id);

        verify(ratingServiceInterface).deleteRating(id);
    }
}

