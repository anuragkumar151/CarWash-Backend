package com.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.user.model.User;

public interface UserServiceInterface {
	
	public User createUser(User user);
	 public List<User> getAllUsers();
	public Optional<User> getUserById(int id);
	public User getUserByemail(String email);
	public User updateUser(int userId, User user);
	public ResponseEntity<String> updateUserDetailsByEmail(String email,User updatedUser) ;
	public void deleteUser(int id);
}
