package com.user.service;

import java.util.List;

import com.user.model.Ratings;

public interface RatingServiceInterface {

	public List<Ratings> getAllRatings() ;
	public Ratings getRatingById(int id) ;
	public Ratings addRating(Ratings rating) ;
	public Ratings updateRating(int id, Ratings updatedRating);
	public void deleteRating(int id);
}
