package com.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.user.dao.UserRepo;
import com.user.model.User;

@Service
public class UserService implements UserServiceInterface {

	@Autowired
	private UserRepo userRepo;

	@Autowired
	private PasswordEncoder passwordEncoder;

	// Create a new user
	public User createUser(User user) {
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		return userRepo.save(user);
	}
	
	//Find all users
	 public List<User> getAllUsers() {
	        return userRepo.findAll();
	    }

	//  Get a user by their ID
	public Optional<User> getUserById(int userId) {
		return userRepo.findById(userId);
	}

	// Get a user by their email
	public User getUserByemail(String email) {
		return userRepo.findByEmail(email);
	}
	
	// Update a user by their ID 
	public User updateUser(int userId, User user) {
		User existingUser = userRepo.findById(userId)
				.orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + userId));

		// Update the properties of the existing user
		existingUser.setFullname(user.getFullname());
		existingUser.setContactNo(user.getContactNo());
		existingUser.setEmail(user.getEmail());
		existingUser.setPassword(user.getPassword());

		// Save the updated user to the database
		return userRepo.save(existingUser);
	}

	// Update user details by email
	public ResponseEntity<String> updateUserDetailsByEmail(String email, User updatedUser) {

		User existingUser = userRepo.findByEmail(email);

		if (existingUser == null) {
			return new ResponseEntity<>("User with email " + email + " not found.", HttpStatus.NOT_FOUND);
		}

		// Update the necessary fields
		existingUser.setEmail(updatedUser.getEmail());
		existingUser.setFullname(updatedUser.getFullname());
		existingUser.setContactNo(updatedUser.getContactNo());
		existingUser.setPassword(passwordEncoder.encode(updatedUser.getPassword()));

		// Save the updated user
		userRepo.save(existingUser);
		return new ResponseEntity<>("User details updated successfully.", HttpStatus.OK);
	}

	// Delete a user by their ID
	public void deleteUser(int id) {
		if (userRepo.existsById(id)) {
			userRepo.deleteById(id);
		}
	}
}
