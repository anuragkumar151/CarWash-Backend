package com.user.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.dao.RatingRepo;
import com.user.model.Ratings;

@Service
public class RatingService implements RatingServiceInterface{

    @Autowired
    private RatingRepo ratingRepo;

    public List<Ratings> getAllRatings() {
        return ratingRepo.findAll();
    }

    public Ratings getRatingById(int id) {
        return ratingRepo.findById(id).get();
    }

    public Ratings addRating(Ratings rating) {
        int id = rating.getId();
        if (ratingRepo.existsById(id)) {
            throw new IllegalArgumentException("Rating with ID: " + id + " already exists");
        }
        return ratingRepo.save(rating);
    }

    public Ratings updateRating(int id, Ratings updatedRating) {
       if(!ratingRepo.existsById(id)) {
    	   return null;
       }
       updatedRating.setId(id);
       return ratingRepo.save(updatedRating);
    }

    public void deleteRating(int id) {
      ratingRepo.deleteById(id);
    }

}
