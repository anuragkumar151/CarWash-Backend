package com.user.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.user.model.Ratings;
import com.user.model.User;
import com.user.service.RatingServiceInterface;
import com.user.service.UserServiceInterface;

@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserServiceInterface userServiceInterface;

	@Autowired
	private RatingServiceInterface ratingServiceInterface;

	@GetMapping("/all")
	public List<User> getAllUsers() {
		logger.info("Fetching all users");
		return userServiceInterface.getAllUsers();
	}

	@GetMapping("/{id}")
	public Optional<User> getUserById(@PathVariable int id) {
		logger.info("Fetching user with ID: {}", id);
		return userServiceInterface.getUserById(id);
	}

	@GetMapping("/get/{email}")
	public User getUserByEmail(@PathVariable String email) {
		logger.info("Fetching user by email: {}", email);
		return userServiceInterface.getUserByemail(email);
	}

	@PostMapping("/add")
	public User createUser(@RequestBody User user) {
		logger.info("Creating user: {}", user);
		return userServiceInterface.createUser(user);
	}

	@PutMapping("/change/{id}")
	public User updateUser(@PathVariable int id, @RequestBody User user) {
		logger.info("Updating user with ID: {}, User: {}", id, user);
		return userServiceInterface.updateUser(id, user);
	}

	@PutMapping("/edit/{email}")
	public ResponseEntity<String> updateUserByEmail(@PathVariable String email, @RequestBody User user) {
		logger.info("Updating user with email: {}, User: {}", email, user);
		return userServiceInterface.updateUserDetailsByEmail(email, user);
	}

	@DeleteMapping("/{id}")
	public void deleteUser(@PathVariable int id) {
		logger.info("Deleting user with ID: {}", id);
		userServiceInterface.deleteUser(id);
	}

	@GetMapping("/ratings")
	public List<Ratings> getAllRatings() {
		logger.info("Fetching all ratings");
		return ratingServiceInterface.getAllRatings();
	}

	@GetMapping("/ratings/{id}")
	public Ratings getRatingById(@PathVariable int id) {
		logger.info("Fetching rating by ID: {}", id);
		return ratingServiceInterface.getRatingById(id);
	}

	@PostMapping("/ratings/add")
	public Ratings addRating(@RequestBody Ratings rating) {
		logger.info("Adding new rating: {}", rating);
		return ratingServiceInterface.addRating(rating);
	}

	@PutMapping("/ratings/{id}")
	public Ratings updateRating(@PathVariable int id, @RequestBody Ratings updatedRating) {
		logger.info("Updating rating with ID: {}, Rating: {}", id, updatedRating);
		return ratingServiceInterface.updateRating(id, updatedRating);
	}

	@DeleteMapping("/ratings/{id}")
	public void deleteRating(@PathVariable int id) {
		logger.info("Deleting rating with ID: {}", id);
		ratingServiceInterface.deleteRating(id);
	}
}
