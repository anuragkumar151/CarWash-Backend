package com.booking.service;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.booking.model.TransactionDetails;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;

@Service
public class TransactionService {
	private static final String KEY = "rzp_test_7aUfDW2fyZTjB4";

	private static final String KEY_SECRET = "LdDlbPOU2t6W8ct3b6J5G5QT";

	private static final String CURRENCY = "INR";

	public TransactionDetails createTransaction(Double amount) {

		try {

			JSONObject jsonObject = new JSONObject();

			jsonObject.put("amount", (amount * 100));

			jsonObject.put("currency", CURRENCY);

			RazorpayClient razorpayClient = new RazorpayClient(KEY, KEY_SECRET);

			Order order = razorpayClient.orders.create(jsonObject);

//            logger.info("Order Details: {}", order);

			return prepareTransactionDetails(order);

			// {"amount":100000,"amount_paid":0,"notes":[],"created_at":1686671711,

//                "amount_due":100000,"currency":"INR","receipt":null,

//                "id":"order_M1TGYf2QVnh43Y","entity":"order","offer_id":null,

//                "status":"created","attempts":0}

		} catch (Exception e) {

//            logger.info("RazorPay Exception: {}", e.getMessage());

		}

		return null;

	}

	private TransactionDetails prepareTransactionDetails(Order order) {

		String orderId = order.get("id");

		String currency = order.get("currency");

		Integer amount = order.get("amount");

		String status = order.get("status");

		TransactionDetails transactionDetails = new TransactionDetails(orderId, currency, amount, status);

		return transactionDetails;

	}
}
