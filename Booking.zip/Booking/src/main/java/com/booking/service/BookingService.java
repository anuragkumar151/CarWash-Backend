package com.booking.service;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.dao.BookingRepo;
import com.booking.exception.BookingNotFoundException;
import com.booking.model.BookingDetails;

@Service
public class BookingService implements BookingServiceInterface {

	@Autowired
	private BookingRepo bookingRepo;

	// Find all orders
	public List<BookingDetails> findAll() {

		List<BookingDetails> booking = bookingRepo.findAll();
		if (booking.isEmpty()) {
			throw new BookingNotFoundException("No Booking Found");
		}
		return booking;
	}

	// Find order by id
	public BookingDetails findOne(int orderId) {

		BookingDetails booking = bookingRepo.findById(orderId).get();
		if (booking == null) {
			throw new BookingNotFoundException("Booking not found for orderId: " + orderId);
		}
		return booking;
	}
	
	// Find order by email
		public List<BookingDetails> findByEmail(String email) {

			List<BookingDetails> booking = bookingRepo.findByEmail(email);
			if (booking == null) {
				throw new BookingNotFoundException("Booking not found for email: " + email);
			}
			return booking;
		}

	// To add an order
		public BookingDetails addOrder(BookingDetails booking) {
	        // Save the booking
	        int orderId = booking.getOrderId();
	        if (bookingRepo.existsById(orderId)) {
	            throw new IllegalArgumentException("Booking with ID: " + orderId + " already exists");
	        }
	        BookingDetails savedBooking = bookingRepo.save(booking);

	        // Send booking confirmation email
	        sendBookingConfirmationEmail(savedBooking);

	        return savedBooking;
	    }
		
	//Send confirmation email	
		public void sendBookingConfirmationEmail(BookingDetails booking) {
		    // Email configuration
		    String host = "smtp.gmail.com";
		    int port = 587; // or the appropriate port for your email service
		    String username = "anuragkumar88583@gmail.com";
		    String password = "lngniikzykitjefe";

		    // Email content
		    String recipientEmail = "anuragkumar88583@gmail.com";
		    String subject = "Booking Confirmation";
		    String messageContent = "Dear Customer,\n\nThank you for your booking. Here are the details:\n\n"
		            + "Name: " + booking.getName() + "\n"
		            + "Email: " + booking.getEmail() + "\n"
		            + "Car Name: " + booking.getCarName() + "\n"
		            + "Phone No:"  +booking.getPhoneNo() +"\n"
		            + "Wash Pack:"  +booking.getWashPack() + "\n"
		            + "Date:"  +booking.getDate() +"\n"
		            +  "Time:"  +booking.getTime() +"\n"
		            + "Address:" +booking.getAddress() +"\n"
		            // Include other booking details as needed
		            + "\n\nThank you,\n Best Wash";

		    // Configure email properties
		    Properties properties = new Properties();
		    properties.put("mail.smtp.auth", "true");
		    properties.put("mail.smtp.starttls.enable", "true");
		    properties.put("mail.smtp.host", host);
		    properties.put("mail.smtp.port", port);

		    // Create a Session with authentication
		    Session session = Session.getInstance(properties, new Authenticator() {
		        protected PasswordAuthentication getPasswordAuthentication() {
		            return new PasswordAuthentication(username, password);
		        }
		    });

		    try {
		        // Create a MimeMessage object
		        MimeMessage message = new MimeMessage(session);

		        // Set the recipient address
		        message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipientEmail));

		        // Set the subject
		        message.setSubject(subject);

		        // Set the message content
		        message.setText(messageContent);

		        // Send the email
		        Transport.send(message);
		    } catch (MessagingException e) {
		        e.printStackTrace();
		    }
		}	
		
	// To delete
	public void deleteOrder(int orderId) {

		bookingRepo.deleteById(orderId);
	}

	// To Update using orderId
	public BookingDetails updateBookingDetails(int orderId, BookingDetails bookingDetails) {

		BookingDetails booking = bookingRepo.findById(orderId).get();
		if (booking == null) {
			throw new BookingNotFoundException("Booking not found for orderID: " + orderId);
		}
		booking.setWashPack(bookingDetails.getWashPack());
		booking.setCarName(bookingDetails.getCarName());
		booking.setEmail(bookingDetails.getEmail());
		booking.setPhoneNo(bookingDetails.getPhoneNo());
		booking.setAddress(bookingDetails.getAddress());
		booking.setDate(bookingDetails.getDate());
		booking.setTime(bookingDetails.getTime());
		BookingDetails savedBooking = bookingRepo.save(booking);
		return savedBooking;
	}
	
	// To update using email
	  public BookingDetails updateBookingDetailsByEmail(String email, BookingDetails bookingDetails) {
		  BookingDetails booking = bookingRepo.findByEmail(email).get(0);
			if (booking == null) {
				throw new BookingNotFoundException("Booking not found for orderID: " + email);
			}
			booking.setWashPack(bookingDetails.getWashPack());
			booking.setCarName(bookingDetails.getCarName());
			booking.setEmail(bookingDetails.getEmail());
			booking.setPhoneNo(bookingDetails.getPhoneNo());
			booking.setAddress(bookingDetails.getAddress());
			booking.setDate(bookingDetails.getDate());
			booking.setTime(bookingDetails.getTime());
			BookingDetails savedBooking = bookingRepo.save(booking);
			return savedBooking;
		}

}
