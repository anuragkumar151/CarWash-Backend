package com.example.Admin;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.booking.controller.BookingController;
import com.booking.exception.BookingNotFoundException;
import com.booking.model.BookingDetails;
import com.booking.model.TransactionDetails;
import com.booking.model.Washer;
import com.booking.service.BookingServiceInterface;
import com.booking.service.TransactionService;
import com.booking.service.WasherServiceInterface;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class BookingControllerTest {

    @Mock
    private BookingServiceInterface bookingServiceInterface;

    @Mock
    private WasherServiceInterface washerServiceInterface;

    @Mock
    private TransactionService transactionService;

    @InjectMocks
    private BookingController bookingController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindAllBookings() {
        List<BookingDetails> bookings = new ArrayList<>();
        // Add bookings to the list

        when(bookingServiceInterface.findAll()).thenReturn(bookings);

        List<BookingDetails> result = bookingController.findAll();

        assertEquals(bookings, result);
    }

    @Test
    public void testFindOneBooking() throws BookingNotFoundException {
        int orderId = 1;
        BookingDetails booking = new BookingDetails();
        // Set properties of booking

        when(bookingServiceInterface.findOne(orderId)).thenReturn(booking);

        BookingDetails result = bookingController.findOne(orderId);

        assertEquals(booking, result);
    }

    @Test
    public void testGetUserDetailsByEmail() {
        String email = "test@example.com";
        List<BookingDetails> bookings = new ArrayList<>();
        // Add bookings to the list

        when(bookingServiceInterface.findByEmail(email)).thenReturn(bookings);

        List<BookingDetails> result = bookingController.getUserDetailsByEmail(email);

        assertEquals(bookings, result);
    }

    @Test
    public void testAddBooking() throws BookingNotFoundException {
        BookingDetails booking = new BookingDetails();
        // Set properties of booking

        BookingDetails addedBooking = new BookingDetails();
        // Set properties of addedBooking

        when(bookingServiceInterface.addOrder(booking)).thenReturn(addedBooking);

        ResponseEntity<BookingDetails> response = bookingController.addBooking(booking);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(addedBooking, response.getBody());
    }

    @Test
    public void testUpdateBooking() {
        int orderId = 1;
        BookingDetails bookingDetails = new BookingDetails();
        // Set properties of bookingDetails

        BookingDetails updatedBooking = new BookingDetails();
        // Set properties of updatedBooking

        when(bookingServiceInterface.updateBookingDetails(orderId, bookingDetails)).thenReturn(updatedBooking);

        ResponseEntity<BookingDetails> response = bookingController.updateBooking(orderId, bookingDetails);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(updatedBooking, response.getBody());
    }

    @Test
    public void testUpdateBookingDetailsByEmail() {
        String email = "test@example.com";
        BookingDetails bookingDetails = new BookingDetails();
        // Set properties of bookingDetails

        BookingDetails updatedBooking = new BookingDetails();
        // Set properties of updatedBooking

        when(bookingServiceInterface.updateBookingDetailsByEmail(email, bookingDetails)).thenReturn(updatedBooking);

        ResponseEntity<BookingDetails> response = bookingController.updateBookingDetailsByEmail(email, bookingDetails);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(updatedBooking, response.getBody());
    }

    @Test
    public void testDeleteOrder() {
        int orderId = 1;

        bookingController.deleteOrder(orderId);

        verify(bookingServiceInterface).deleteOrder(orderId);
    }

    @Test
    public void testGetAllWashers() {
        List<Washer> washers = new ArrayList<>();
        // Add washers to the list

        when(washerServiceInterface.All()).thenReturn(washers);

        List<Washer> result = bookingController.getAllWashers();

        assertEquals(washers, result);
    }

    @Test
    public void testCreateTransaction() {
        double amount = 100.0;
        TransactionDetails transactionDetails = new TransactionDetails();
        // Set properties of transactionDetails

        when(transactionService.createTransaction(amount)).thenReturn(transactionDetails);

        TransactionDetails result = bookingController.createTransaction(amount);

        assertEquals(transactionDetails, result);
    }
}
