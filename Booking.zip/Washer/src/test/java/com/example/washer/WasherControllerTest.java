package com.example.washer;

import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.washer.controller.WasherController;
import com.washer.model.Washer;
import com.washer.service.WasherServiceInterface;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class WasherControllerTest {

    @Mock
    private WasherServiceInterface washerServiceInterface;

    @InjectMocks
    private WasherController washerController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindAll() {
        List<Washer> washers = new ArrayList<>();
        // Add washers to the list

        when(washerServiceInterface.getAllWashers()).thenReturn(washers);

        List<Washer> result = washerController.findAll();

        assertEquals(washers, result);
    }

    @Test
    public void testGetRandomWasher() {
        Washer washer = new Washer();
        // Set properties of washer

        when(washerServiceInterface.getRandomWasher()).thenReturn(washer);

        Washer result = washerController.getRandomWasher();

        assertEquals(washer, result);
    }

    @Test
    public void testGetWasherById() {
        int wid = 1;
        Washer washer = new Washer();
        // Set properties of washer

        when(washerServiceInterface.getUserById(wid)).thenReturn(washer);

        Washer result = washerController.getWasherById(wid);

        assertEquals(washer, result);
    }

    @Test
    public void testAddWasher() {
        Washer washer = new Washer();
        // Set properties of washer

        when(washerServiceInterface.saveUser(washer)).thenReturn(washer);

        Washer result = washerController.addWasher(washer);

        assertEquals(washer, result);
    }

    @Test
    public void testUpdateWasher() {
        String email = "test@example.com";
        Washer washer = new Washer();
        // Set properties of washer

        when(washerServiceInterface.updateUser(email, washer)).thenReturn(washer);

        ResponseEntity<Washer> response = washerController.updateWasher(email, washer);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(washer, response.getBody());
    }

    @Test
    public void testUpdateWasher_NotFound() {
        String email = "test@example.com";
        Washer washer = new Washer();
        // Set properties of washer

        when(washerServiceInterface.updateUser(email, washer)).thenReturn(null);

        ResponseEntity<Washer> response = washerController.updateWasher(email, washer);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
    }

    @Test
    public void testDeleteWasher() {
        int wid = 1;

        washerController.deleteWasher(wid);

        verify(washerServiceInterface).deleteUser(wid);
    }
}
