package com.washer.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.washer.model.Washer;
import com.washer.service.WasherServiceInterface;

@RestController
@RequestMapping("/washer")
@CrossOrigin(origins = "http://localhost:3000")
public class WasherController {

	@Autowired
	private WasherServiceInterface washerServiceInterface;

	private static final Logger LOGGER = LoggerFactory.getLogger(WasherController.class);

	@GetMapping("/get")
	public List<Washer> findAll() {
		LOGGER.info("Fetching all washers");
		return washerServiceInterface.getAllWashers();
	}

	@GetMapping("/random")
	public Washer getRandomWasher() {
		// Retrieve a random washer from the washer service
		return washerServiceInterface.getRandomWasher();
	}

	@GetMapping("/get/{wid}")
	public Washer getWasherById(@PathVariable int wid) {
		LOGGER.info("Fetching washer with ID: {}", wid);
		return washerServiceInterface.getUserById(wid);
	}

	@PostMapping("/add")
	public Washer addWasher(@RequestBody Washer washer) {
		LOGGER.info("Adding new washer: {}", washer);
		return washerServiceInterface.saveUser(washer);
	}

//	@PutMapping("/update/{email}")
//	public Washer updateWasher(@PathVariable String email, @RequestBody Washer washer) {
//		LOGGER.info("Updating washer with Email: {}", email);
//		return washerServiceInterface.updateUser(email, washer);
//	}
//	
	  @PutMapping("/update/{email}")
	    public ResponseEntity<Washer> updateWasher(@PathVariable String email, @RequestBody Washer washer) {
	        LOGGER.info("Updating washer with Email: {}", email);
	        
	        Washer updatedWasher = washerServiceInterface.updateUser(email, washer);
	        if (updatedWasher != null) {
	            return ResponseEntity.ok(updatedWasher);
	        } else {
	            return ResponseEntity.notFound().build();
	        }
	    }

	@DeleteMapping("/{wid}")
	public void deleteWasher(@PathVariable int wid) {
		LOGGER.info("Deleting washer with ID: {}", wid);
		washerServiceInterface.deleteUser(wid);
	}

}
