package com.washer.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.washer.model.Washer;

@Service
public interface WasherServiceInterface {

	public List<Washer> getAllWashers();

	public Washer getRandomWasher();

	public Washer getUserById(int wid);

	public Washer saveUser(Washer washer);

	public Washer updateUser(String email, Washer washer);

	public void deleteUser(int wid);

}
