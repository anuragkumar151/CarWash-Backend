package com.example.Admin;

import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.admin.controller.AdminController;
import com.admin.model.BookingDetails;
import com.admin.model.WashPack;
import com.admin.model.Washer;
import com.admin.service.AdminServiceInterface;
import com.admin.service.WashPackServiceInterface;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AdminControllerTest {

    @Mock
    private WashPackServiceInterface washPackServiceInterface;

    @Mock
    private AdminServiceInterface adminServiceInterface;

    @InjectMocks
    private AdminController adminController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testAddWashPack() {
        WashPack washPack = new WashPack();
        // Set properties of washPack

        when(washPackServiceInterface.addWashPack(washPack)).thenReturn(washPack);

        ResponseEntity<WashPack> response = adminController.addWashPack(washPack);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(washPack, response.getBody());
    }

    @Test
    public void testGetAllWashPacks() {
        List<WashPack> washPacks = new ArrayList<>();
        // Add wash packs to the list

        when(washPackServiceInterface.getAllWashPacks()).thenReturn(washPacks);

        ResponseEntity<List<WashPack>> response = adminController.getAllWashPacks();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(washPacks, response.getBody());
    }

    @Test
    public void testFindWashPackByName() {
        String name = "SomeWashPackName";
        WashPack washPack = new WashPack();
        // Set properties of washPack

        when(washPackServiceInterface.findWashPackByName(name)).thenReturn(washPack);

        ResponseEntity<WashPack> response = adminController.findWashPackByName(name);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(washPack, response.getBody());
    }

    @Test
    public void testDeleteWashPack() {
        String id = "someId";

        adminController.deleteWashPack(id);

        verify(washPackServiceInterface).deleteWashPack(id);
    }

    @Test
    public void testUpdateWashPack() {
        String id = "someId";
        WashPack washPack = new WashPack();
        // Set properties of washPack

        when(washPackServiceInterface.updateWashPack(id, washPack)).thenReturn(washPack);

        ResponseEntity<WashPack> response = adminController.updateWashPack(id, washPack);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(washPack, response.getBody());
    }

    @Test
    public void testGetAllBookingDetails() {
        List<BookingDetails> bookingDetails = new ArrayList<>();
        // Add booking details to the list

        when(adminServiceInterface.bookingDetails()).thenReturn(bookingDetails);

        List<BookingDetails> result = adminController.getorder();

        assertEquals(bookingDetails, result);
    }

    @Test
    public void testGetBookingDetails() {
        String orderId = "someOrderId";
        BookingDetails bookingDetails = new BookingDetails();
        // Set properties of bookingDetails

        when(adminServiceInterface.findOne(orderId)).thenReturn(bookingDetails);

        BookingDetails result = adminController.getBookingDetails(orderId);

        assertEquals(bookingDetails, result);
    }

    @Test
    public void testDeleteBooking() {
        String orderId = "someOrderId";

        adminController.deleteBooking(orderId);

        verify(adminServiceInterface).deleteOrder(orderId);
    }

    @Test
    public void testGetAllWashers() {
        List<Washer> washers = new ArrayList<>();
        // Add washers to the list

        when(adminServiceInterface.washer()).thenReturn(washers);

        List<Washer> result = adminController.getAllWashers();

        assertEquals(washers, result);
    }

}
